﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cars
{
    class Program
    {
        static void Main(string[] args)
        {
            var cars = ProcessFile("fuel.csv");


            foreach (var car in cars)
            {
                Console.WriteLine(car.Name);
            }
            var validCars = filterChecd(cars);

     
           
            Console.ReadLine();
        }

        private static List<Car> filterChecd(List<Car> lstcar )
        {
            var queryFilter = from lst in lstcar
                              where lst.Manufacturer == "Ferrari" && lst.Year == 2016 &&  DateTime.TryParseExact()
                              orderby lst.Combined descending, lst.Name ascending
                              select lst;

            foreach (var item in queryFilter.Take(10))
            {
                Console.WriteLine($"{item.Name,-20} {item.Manufacturer,10} {item.Combined,20}");
            }
            //  return queryFilter.ToList();

            var query2 = lstcar.Where(c => c.Manufacturer == "Ferrari" && c.Year == 2016)
                              .OrderByDescending(c => c.Combined)
                              .ThenBy(c => c.Name)
                              .Select(c => c)
                              .ToList();
            Console.WriteLine(System.Environment.NewLine);
       
            Console.WriteLine(System.Environment.NewLine);
            foreach (var item in query2.Take(10))
            {
                Console.WriteLine($"{item.Name,-20} {item.Combined,20}");
            }

            return queryFilter.ToList();
        }

        private static List<Car> ProcessFile(string path)
        {
            //Populated all records in list
            //Method Query
                 return  
                       File.ReadAllLines(path)
                         .Skip(1)
                         .Where(line => line.Length > 1)
                         .Select(Car.ParseFromCSV)
                         .ToList();

       
            //Structurl Query

            /*
            var query1 = from line in File.ReadAllLines(path).Skip(1)
                         where line.Length > 1
                         select Car.ParseFromCSV(line);
            return query1.ToList();
            */
            
        }
    }
}
