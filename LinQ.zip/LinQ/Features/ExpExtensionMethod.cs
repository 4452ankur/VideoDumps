﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Features
{
    public static class ExpExtensionMethod
    {
        public static int item_Count<T>(this IEnumerable<T> Sequence)
        {
            int count = 0;
            foreach (var item in Sequence)
            {
                count += 1;
            }
            return count;
        }
    }
}
