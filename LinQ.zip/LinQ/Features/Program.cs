﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Features
{
   public class Program 
    {
        static void Main(string[] args)
        {
            //Func <> 17 generic type overload,last parameter describe return type.
            Func<int, int> Square = x => x * x;

            Console.WriteLine(Square(3));

            Func<double, int, double> Add = (x, y) => x + y;
            Console.WriteLine(Add(3.5,5));

         
            Employee[] Developer = new Employee[]
            {
                new Employee {Id="1002",Name="Ankur" },
                new Employee {Id="1005",Name="Sankar" },
                new Employee {Id="1019",Name="Arnab" },
                new Employee {Id="756",Name="Arijit" },
                new Employee {Id="10021",Name="Ankk" },
                new Employee {Id="10051",Name="Abir" },
                new Employee {Id="10191",Name="Aroti" },
                new Employee {Id="7561",Name="Avilasha" }
            };

            List<Employee> Sales = new List<Employee>()
            {
                new Employee {Id="93",Name="Raka" }
            };
            // example extension method
            Console.WriteLine(Developer.item_Count());
            Console.WriteLine(System.Environment.NewLine);

            foreach (var item in Sales)
            {
               
                Console.WriteLine($"{item.Id,-20} : {item.Name,10}");
            }
            Console.WriteLine(System.Environment.NewLine);
            // Filter condition
            foreach (var item in Developer.Where(e=>e.Name.StartsWith("A")))
            {

                Console.WriteLine($"{item.Id,-20} : {item.Name,10}");
              
            }
            Console.WriteLine(System.Environment.NewLine);
            // Filter condition
            // Query Syntex 

            var query2 = from dev in Developer
                         where dev.Name.Length > 4 && dev.Name.StartsWith("A")
                         orderby dev.Id descending
                         select dev;
           List<Employee>lst = query2.ToList();
            foreach (var item in lst)
            {
                Console.WriteLine($"{item.Id,-20} : {item.Name,10}");
            }

            // Console.WriteLine("Query Syntex  " + query2.ToList());

            // Method Syntex
            Console.WriteLine(System.Environment.NewLine);
            var query1 = Developer.Where(e => e.Name.Length > 4 && e.Name.StartsWith("A"))
                                .OrderByDescending(e => e.Id)
                                .Select(e => e);
            foreach (var item in query1)
            {
                Console.WriteLine($"{item.Id,-20} : {item.Name,10}");
            }

            //Console.WriteLine("Method Syntex  " + query1);


            Console.ReadLine();
        }

       
    }
}
