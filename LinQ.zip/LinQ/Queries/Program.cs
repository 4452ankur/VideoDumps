﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queries
{
    class Program
    {
        static void Main(string[] args)
        {
            var movies = new List<Movie>
            {
                new Movie {Title="Ram Ratan",Rating=8.9f,Year=2018 },
                  new Movie {Title="Hera Feri",Rating=7.6f,Year=2016 },
                    new Movie {Title="Babu",Rating=6.9f,Year=1968 },
                      new Movie {Title="DDLG",Rating=5.9f,Year=2019 },
            };
            // after 2000 year
            // Method query
            var Query1 = movies.Where(m => m.Year > 2000);

            Console.WriteLine($"{"Title",-20} : {"Rating",10:N0} : {"Year",10:N0} ");
            foreach (var item in Query1)
            {
                Console.WriteLine($"{item.Title,-20} : {item.Rating,10:N0} : {item.Year,10:N0} ");
            }

            Console.ReadLine();
        }
    }
}
