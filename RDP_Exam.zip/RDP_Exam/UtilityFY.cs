using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RDP_Exam
{
    public class UtilityFY
    {
        public void Process()
        {
            // D:\RnD\RDP_Frame_Exam\Read
            //ReadTxt.txt
            FileCopy();

            LstRaw12(@"D:\RnD\RDP_Frame_Exam\Read", "ReadTxt.txt");
        }

        protected List<Prod_Prop> LstRaw12(string source, string fileName)
        {
            List<Prod_Prop> lstRw = new List<Prod_Prop>();
            try
            {

                string filedtls = System.IO.Path.Combine(source, fileName);
                FileStream fs_strem = new FileStream(filedtls, FileMode.Open, FileAccess.Read);
                using (StreamReader Strm = new StreamReader(fs_strem))
                {
                    string AllText = Strm.ReadToEnd();
                    string[] TextArray = AllText.Split('\n');
                    string line;
                    for (int i = 0; i < TextArray.Length; i++)
                    {
                        Prod_Prop objProd = new Prod_Prop();
                        line = TextArray[i];
                        string[] lineArray = line.Replace('\r'.ToString(), "".ToString()).Split(',');
                        objProd.PropId = Convert.ToInt32(lineArray[0]);
                        objProd.ModelId = Convert.ToString(lineArray[1]);
                        objProd.ProdDt = Convert.ToString(lineArray[2]);
                        objProd.ModDt = Convert.ToString(lineArray[3]);
                        objProd.ModAmount = Convert.ToInt32(lineArray[4]);

                        lstRw.Add(objProd);

                    }


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return lstRw;
        }

        public void FileCopy()
        {
            string OldfileDirectory = @"D:\RnD\RDP_Frame_Exam\Read";
            string NewfileDirectory = @"D:\RnD\RDP_Frame_Exam\Archive";
            string OldFileNm = "ReadTxt_12302017.txt";

            string OldFileNmWthDir = Path.Combine(OldfileDirectory, OldFileNm);
            string currentDt = "_" + DateTime.Now.ToString("MMyyyy");

            string NewFlName = OldFileNm.Replace("_12302017", "_"+ currentDt+"_processed");
            string NwFileWthDir = Path.Combine(NewfileDirectory, NewFlName);

            if (!File.Exists(OldFileNmWthDir))
            {
                Console.WriteLine("File is not exists");
                return;
            }

            if(File.Exists(NwFileWthDir))
            {
                File.Delete(NwFileWthDir);
            }
            File.Copy(OldFileNmWthDir, NwFileWthDir);

        }


    }

    }

