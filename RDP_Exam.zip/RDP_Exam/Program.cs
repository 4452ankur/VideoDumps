using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RDP_Framework
{
class Program
    {
        static void Main(string[] args)
        {
            Utility utility = new Utility();
            utility.Process_AllMethods();
            Console.WriteLine("Thank u");
            Console.ReadLine();
        }
    }
}