﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit_Test1
{
    class Program
    {
        
        static void Main(string[] args)
        {
         //   int add, multi=0;

            Calculator cal = new Calculator();
          cal.Add(5, 6);
            Console.WriteLine("Addtion " + cal.ReturnAdd);
            cal.Mul(5, 6);
            Console.WriteLine("multipication " + cal.ReturnMul);
            Console.Read();

        }
    }
}
 