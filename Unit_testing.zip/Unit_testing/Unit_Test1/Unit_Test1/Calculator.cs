﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit_Test1
{
    public class Calculator : ICalculater
    {
        private int addVal, mulVal;

        public void Add(int num1, int num2)
        {
            addVal = num1 + num2;
        }

        public int ReturnAdd
        {
            get
            {
                return addVal;
            }
        }
        
        public void Mul(int num1, int num2)
        {
            mulVal= num1 * num2;
        }

        public int ReturnMul
        {
            get
            {
                return mulVal;
            }
        }
    }
}
