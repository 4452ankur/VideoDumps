﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
using NUnit.Framework;
using Unit_Test1;

namespace UnitTestProj
{

    [TestFixture] // TestFixture attribute   to create the test class
    public class CalculatorTest
    {
       
    
        ICalculater Sut;
        [Test] // Test attribute to create the test method

        // TestFixtureSetUp is a code which gets executed before the execution of any test
        // TestFixtureTearDown is a piece of code which gets executed after execution of all the tests.
       //  [TestFixtureSetUp]
        public void TestSetup()
        {
            Sut = new Calculator();
        }


        [Test]
        public void ShouldAddTwoNum()
        {
           
          //  int expectedResult = sut.Add(num1, num2);
           // Assert.That(expectedResult, Is.EqualTo(11));

            // Arrange
            int num1 = 5;
            int num2 = 6;
            int expected = 11;
            ICalculater sut = new Calculator();
            // sut-- Sistem under Test


            // Act
            sut.Add(num1, num2);

            // Assert
            int actual = sut.ReturnAdd;
            Assert.AreEqual(expected, actual, 0.001, "Not properly added");

          //  Assert.That(actual, Is.EqualTo(11));

        }

        [Test]
        public void ShouldMulTwoNum()
        {
            // Arrange
            int num1 = 5;
            int num2 = 6;
            int expected = 30;
            ICalculater sut = new Calculator();

            // Act
            sut.Mul(num1, num2);

            // Assert
            int actual = sut.ReturnAdd;
            Assert.AreEqual(expected, actual, 0.001, "Not properly multiply");

          // sut.Mul(num1, num2);
           // Assert.That(expectedResult, Is.EqualTo(30));
           
        }
    }
}
 