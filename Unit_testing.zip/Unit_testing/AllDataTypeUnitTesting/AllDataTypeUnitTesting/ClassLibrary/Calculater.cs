﻿using AllDataTypeUnitTesting.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllDataTypeUnitTesting.ClassLibrary
{
   public class Calculater : ICalculater
    {
        public int StoreNum1
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public int StoreNum2
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public double AddDoubles(double num1, double num2)
        {
            return num1 + num2;
        }

        public int AddInts(int num1, int num2)
        {
            return num1 + num2;
        }

        public int Divide(int num1, int num2)
        {
            if(num1>100)
            {
                throw new ArgumentOutOfRangeException("num2");
               
            }
            return num1 / num2;
        }
        public int Multipication(int num1, int num2)
        {
            return num1 * num2;
        }
        public int Subtraction(int num1, int num2)
        {
            return num1 - num2;
        }


    }
}
