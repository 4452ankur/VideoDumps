﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AllDataTypeUnitTesting.Model;

namespace AllDataTypeUnitTesting.ClassLibrary
{
   public class ObjectTypePropertyFactory
    {
        public object Create(bool isBoss)
        {
            if(isBoss)
            {
                return new BossEnemy();
            }
            return new NormalEnemy();
        }

    }
}
