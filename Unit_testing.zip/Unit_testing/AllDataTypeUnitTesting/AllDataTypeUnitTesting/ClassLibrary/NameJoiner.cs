﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllDataTypeUnitTesting.ClassLibrary
{
   public class NameJoiner
    {
        public string JoinName(string firstName,string lastname)
        {
            return firstName + " " + lastname;
        }
    }
}
