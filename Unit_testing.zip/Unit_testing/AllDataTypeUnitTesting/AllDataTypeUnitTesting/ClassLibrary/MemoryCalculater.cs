﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AllDataTypeUnitTesting.Model;

namespace AllDataTypeUnitTesting.ClassLibrary
{
    public class MemoryCalculater : ICalculater
    {
        private int inum1, inum2;
        public double AddDoubles(double num1, double num2)
        {
            throw new NotImplementedException();
        }

        public int AddInts(int num1, int num2)
        {
            throw new NotImplementedException();
        }
        public int IntSubtraction(int num1, int num2)
        {
            throw new NotImplementedException();
        }


        public int AddInts()
        {
            return inum1 + inum2;
        }

        public int IntSubtra()
        {
            return inum1 - inum2;
        }

        public int Divide(int num1, int num2)
        {
            throw new NotImplementedException();
        }

        public int StoreNum1
        {
            get
            {
                return inum2;
            }

            set
            {
                inum2 = value;
            }
        }

        public int StoreNum2
        {
            get
            {
                return inum1;
            }

            set
            {
                inum1 = value;
            }
        }
    }
}
