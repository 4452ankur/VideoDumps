﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllDataTypeUnitTesting.Model
{
  public  interface ICalculater
    {
        int AddInts(int num1, int num2);
        double AddDoubles(double num1, double num2);
        int Divide(int num1, int num2);
         int StoreNum1{ get; set; }
        int StoreNum2 { get; set; }


    }
}
