﻿using NUnit.Framework;
using AllDataTypeUnitTesting.ClassLibrary;
using System;

namespace UnitTesting
{
    [TestFixture]
   public class CalculaterTest
    {

        [Test]
        public void AddIntsTest()
        {
            //Arrange
            var sut = new Calculater();
            var expected=11;

            //Act
            var actual = sut.AddInts(6, 5);

            //Assert
            Assert.That(actual, Is.EqualTo(expected));
                       
        }
        [Test]
        public void ShoulAddDoublesTest()
        {
            //Arrange
            var sut = new Calculater();
            double expected = 3.3;

            //Act
            double actual = sut.AddDoubles(1.02, 2.01);

            //Assert
            Assert.That(actual, Is.EqualTo(expected));

        }

        [Test]
        public void ShoulAddDoublesTestWithTolerance()
        {
            //Arrange
            var sut = new Calculater();
            double expected = 3.4;

            //Act
            double actual = sut.AddDoubles(1.2, 2.1);

            //Assert
            Assert.That(actual, Is.EqualTo(expected).Within(.20));

        }

        [Test]
        public void ShoulAddDoublesTestWithPercentTolerance()
        {
            //Arrange
            var sut = new Calculater();
            double expected = 102;

            //Act
            double actual = sut.AddDoubles(50, 50);

            //Assert
            Assert.That(actual, Is.EqualTo(expected).Within(2).Percent,"Error");

        }
        [Test]
        public void ShoulAddDoublesTestWithBadTolerance()
        {
            //Arrange
            var sut = new Calculater();
            double expected = 5.5;

            //Act
            double actual = sut.AddDoubles(2.2, 2.2);

            //Assert
            Assert.That(actual, Is.EqualTo(expected).Within(100), "Error");

       
        }
        [Test]
        public void ShoulThroughException()
        {
            //Arrange
            var sut = new Calculater();
            var expected = Throws.TypeOf<DivideByZeroException>();

            //Act
            double actual = sut.Divide(99, 0);

            //Assert
            Assert.That(actual, expected);
            
        }
    }
}
