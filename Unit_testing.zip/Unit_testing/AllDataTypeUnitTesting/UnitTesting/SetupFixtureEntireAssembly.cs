﻿using System;
using NUnit.Framework;
using System.Diagnostics;

namespace UnitTesting
{
    [SetUpFixture]
 public   class SetupFixtureEntireAssembly
    {
        [OneTimeSetUp]
        public void OneTimeEexcuteBeforeEntireAssembly()
        {
            Console.WriteLine("$$$ Before any test in EntireAssembly");
            Debug.WriteLine("$$$ Before any test in EntireAssembly");
        }
        [OneTimeTearDown]
        
        public void OneTimeEexcuteAfterEntireAssembly()
        {
            Console.WriteLine("$$$ After any test in EntireAssembly");
           // TestContext.WriteLine("Message...");
           // Console.WriteLine("Hi Hi World");
            //Trace.WriteLine("Trace Trace the World");
            Debug.WriteLine("$$$ After any test in EntireAssembly");
        }
    }
}
