﻿using NUnit.Framework;
using AllDataTypeUnitTesting;


namespace UnitTesting
{
    [TestFixture]
   public class PlayCharecterReferenceTest
    {
        [Test]
        public void RefrenceEqualityDemo()
        {
            //Arrange
            var player1 = new PlayCharacters ();
            var player2 = new PlayCharacters();
            var actual = player1;
            //Act

          //  var expected = Is.SameAs(player2);

         //   var expected = Is.SameAs(player1);
            var expected = Is.Not.SameAs(player2);

            //Assert
            Assert.That(actual , expected);

        }
    }
}
