﻿using NUnit.Framework;
using AllDataTypeUnitTesting;

namespace UnitTesting
{
    [TestFixture]
    public class PlayCharactersTest
    {
        [Test]
        public void ShoulIncreaseHealtAfterSleeping()
        {
            //Arrange
            var sut = new PlayCharacters { Health = 100 };
            var expected = 100;

            //Act
            sut.Sleep();
            var actual =sut.Health ;

            //Assert
            Assert.That(actual, Is.GreaterThan(expected));

        }

        [Test]
        public void ShouldIncreaseHealtExpectedRangeAfterSleeping()
        {
            //Arrange
            var sut = new PlayCharacters { Health = 100 };
              var expected = Is.InRange(101,200);
            //  var expected = Is.LessThan(101);
           // var expected = Is.LessThanOrEqualTo(101);
            //var expected = Is.GreaterThanOrEqualTo(101);

            //Act
            sut.Sleep();
            var actual = sut.Health;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldNotEmpty()
        {
            //Arrange
            var sut = new PlayCharacters ();
            var expected = Is.Not.Empty;
         

            //Act
          
            var actual = sut.Name;

            //Assert
            Assert.That(actual, expected);

        }

        [Test]
        public void NickNameNullOrNotNull()
        {
            //Arrange
            var sut = new PlayCharacters();
            var expected = Is.Null;
            //var expected = Is.Not.Null;

            //Act

            var actual = sut.NickName;

            //Assert
            Assert.That(actual, expected,"nick name should not Null");

        }
        // Assert In collection
        [Test]
        public void BoolTrue()
        {
            //Arrange
            var sut = new PlayCharacters();
          
            var expected = Is.True;

            //Act

            var actual = sut.IsNoob;

            //Assert
            Assert.That(actual, expected, "True");

        }
        [Test]
        public void ShouldNotDefaultEmptySting()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Is.All.Not.Empty;

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);
            
        }
        [Test]
        public void ShouldHaveMatchString()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Contains.Item("Short Bow");

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldHaveMatchAnyWord()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Has.Some.ContainsSubstring("Sword");

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }

        [Test]
        public void ShouldHaveTwoItem()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Has.Exactly(2).EndsWith("Bow");

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldNotHaveMoreThenOneType()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Is.Unique;

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldNotContainPasificItem()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expected = Has.None.EqualTo("Staff Of Wonder");

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldHaveExpectedItems()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test
            var expectedItem = new[]
            {
                "Long Bow",             
                "Short Bow",
                "Short Sword",

            };
            var expected = Is.EquivalentTo(expectedItem);

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }
        [Test]
        public void ShouldHaveAlphabetOrder()
        {
            //Arange
            var sut = new PlayCharacters(); //sut system under Test

            var expected = Is.Ordered;

            //Act
            var actual = sut.Weapons;

            //Assert
            Assert.That(actual, expected);

        }

    }
}
