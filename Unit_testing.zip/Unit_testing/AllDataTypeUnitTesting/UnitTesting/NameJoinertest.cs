﻿
using NUnit.Framework;
using AllDataTypeUnitTesting.ClassLibrary;

namespace UnitTesting
{
    [TestFixture] // TestFixture attribute   to create the test class
    public class NameJoinertest
    {
        [Test] // test method
        public void JoinNameTest()
        {
            // Arrange
                     
            var sut = new NameJoiner();   // sut-- Sistem under Test
            var expected = "ANKUR BHATTACHARYA";

            // Act
            var actual = sut.JoinName("ANKUR", "BHATTACHARYA");

            //Assert
            
            Assert.That(actual,Is.EqualTo(expected));

            // Assert.That(actual, Is.EqualTo("ANKUR BHATTACHARYA"));
        }
        [Test]
        public void JoinNameCaseInSensetive()
        {
            //Arrange
            var sut = new NameJoiner();
            var expected = "Ankur Bhattacharya";

            //Act
            var actual = sut.JoinName("ANKUR", "BHATTACHARYA");

            //Assert
            Assert.That(actual, Is.EqualTo(expected).IgnoreCase);
        }
        [Test]
        public void JoinNameNotEqualDemo()
        {
            //Arrange
            var sut = new NameJoiner(); //Sistem Under Test
            var expected = "SONAA BHATTACHARYA";
            //Act
            var actual = sut.JoinName("ANKUR", "BHATTACHARYA");
            //Assert
            Assert.That(actual, Is.Not.EqualTo(expected));
        }
    }
}
