﻿using NUnit.Framework;
using AllDataTypeUnitTesting.ClassLibrary;
using AllDataTypeUnitTesting.Model;

namespace UnitTesting
{
    [TestFixture]
    public class ObjectTypePropertyFactoryTest
    {

        [Test]
        public void ShouldCreateNormalEnemy()
        {
            //Arrange
            var sut = new ObjectTypePropertyFactory();
            var expected = Is.TypeOf<NormalEnemy>();

            //Act
            object actual = sut.Create(false);

            //Assert
            Assert.That(actual, expected);
        }

        [Test]
        public void ShouldCreateBossEnemy()
        {
            //Arrange
            var sut = new ObjectTypePropertyFactory();
            var expected = Is.TypeOf<BossEnemy>();

            //Act
            object actual = sut.Create(true);

            //Assert
            Assert.That(actual, expected);
        }

        [Test]
        public void ShouldBeBaseType()
        {
            //Arrange
            var sut = new ObjectTypePropertyFactory();
            var expected = Is.InstanceOf<Enemy>();

            //Act
            object actual = sut.Create(true);

            //Assert
            Assert.That(actual, expected);
        }


        [Test]
        public void CheckPropertyName()
        {
            //Arrange
            var sut = new ObjectTypePropertyFactory();
            var expected = Has.Property("Extrapower");
           // var expected = Has.Property("SomePropertY");

            //Act
            object actual = sut.Create(true);

            //Assert
            Assert.That(actual, expected);
        }
    }
}
