﻿using NUnit.Framework;
using System;
using System.Diagnostics;
using System.Collections;


namespace UnitTesting.SomeNameSpace
{
    [TestFixture]
    public class ClassWithIntemetingBugTest
    {
        [Test]
       // [Repeat(30000)] // repeate the test run 3000 times and if fail then shown error.
        public void ShouldDoWorkTest()
        {
            var sut = new ClassWithIntemetingBug();
            sut.DoWork();
        }
    }
}
