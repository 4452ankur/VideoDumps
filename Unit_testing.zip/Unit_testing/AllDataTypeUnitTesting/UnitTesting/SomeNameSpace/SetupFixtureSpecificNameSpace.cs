﻿using NUnit.Framework;
using System;
using System.Diagnostics;

namespace UnitTesting.SomeNameSpace
{
    [SetUpFixture]
    public class SetupFixtureSpecificNameSpace
    {
        [OneTimeSetUp]
        public void RunBeforeAnyTestInSomeNameSpace()
        {
            Console.WriteLine("### Before any test in SomeNameSpace");
            Debug.WriteLine ("### Before any test in SomeNameSpace");
        }

        [OneTimeTearDown]
        public void RunAfterAnyTestInSomeNameSpace()
        {
          //  Console.WriteLine("### After any test in SomeNameSpace");
            Debug.WriteLine("### After any test in SomeNameSpace");
        }


    }
}
