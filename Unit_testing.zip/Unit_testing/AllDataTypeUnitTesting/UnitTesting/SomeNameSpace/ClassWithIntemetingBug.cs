﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTesting.SomeNameSpace
{
   public class ClassWithIntemetingBug
    {
        public void DoWork()
        {
            // simuliter intement Bug
            if(DateTime.Now.Ticks%2==0)
            {
                throw new ApplicationException("Simelation Bug");
            }
        }
    }
}
