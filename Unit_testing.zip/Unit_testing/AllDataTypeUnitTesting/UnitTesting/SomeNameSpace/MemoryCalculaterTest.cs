﻿using AllDataTypeUnitTesting.ClassLibrary;
using NUnit.Framework;
using System;
using System.Diagnostics;

namespace UnitTesting.SomeNameSpace
{
    [TestFixture]
    public class MemoryCalculaterTest
    {
        MemoryCalculater sut;

        [Test]
        public void ShouldAdd()
        {
            //Arrange
            var expected = 11;

            // Act
            var actual = sut.AddInts();
            Console.WriteLine("AddInts value {0}", actual);
            Debug.WriteLine("AddInts value ShouldAdd {0}", actual);
            //Assert

            Assert.That(actual, Is.EqualTo(expected));
        }
        [Test]
      
        public void ShouldSubtract()
        {

            //Arrange
            var expected = -1;

            // Act
            var actual = sut.IntSubtra();
             Console.WriteLine("ShouldSubtract value {0}", actual);
            Debug.WriteLine("ShouldSubtract value {0}", actual);
            //Assert

            Assert.That(actual, Is.EqualTo(expected));
       
        }

        [SetUp] // execute before every test case
        public void BeforeEachTest()
        {
            Console.WriteLine("Before {0}", TestContext.CurrentContext.Test.Name);
            Debug.WriteLine("Before BeforeEachTest {0}", TestContext.CurrentContext.Test.Name);
            sut = new MemoryCalculater();
            sut.StoreNum1 = 6;
            sut.StoreNum2 = 5;
        }
        [TearDown] // execute after every test case

        public void AfterEachTest()
        {
            Console.WriteLine("After test {0}", TestContext.CurrentContext.Test.Name);
            Debug.WriteLine("After test AfterEachTest {0}", TestContext.CurrentContext.Test.Name);
            sut = null;

        }
        [OneTimeSetUp]//starting  One time execute the code
        public static void BeforeExecuteAnyTest()
        {
            Console.WriteLine("Before execute test {0}");
            Debug.WriteLine("&&&& Before execute test in same class BeforeExecuteAnyTest ");
        }
        [OneTimeTearDown] // After end of One time execute code
        public static void AfterExecuteAllTest()
        {
            Console.WriteLine("After execute all test {0}");
            Debug.WriteLine ("&&&& After execute all test in same class AfterExecuteAllTest ");
        }

    }
}
