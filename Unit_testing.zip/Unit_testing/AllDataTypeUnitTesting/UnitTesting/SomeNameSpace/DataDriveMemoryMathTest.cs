﻿using AllDataTypeUnitTesting.ClassLibrary;
using NUnit.Framework;
using System;
using System.Diagnostics;
using System.Collections;


namespace UnitTesting.SomeNameSpace
{
    [TestFixture]
    public class DataDriveMemoryMathTest
    {
        MemoryCalculater sut;
        [OneTimeSetUp]
        public void OneTimeExecute()
        {
            Debug.WriteLine("*** execute before test");
        }

        [SetUp] //Before execute each test
        public void TestSetUp()
        {
            sut = new MemoryCalculater();
            Debug.WriteLine("Before execute each test");
        }

        [Category("Data Driven")] // catagory example
        [TestCase(8, 4, 12)]
        [TestCase(6, 6, 12)]
        [TestCase(5,6,11)]
        public void AddIntData(int num1,int num2,int exp)
        {
            sut.StoreNum1 = num1;
            sut.StoreNum2 = num2;

            //Arrange
            var expected = exp;

            // Act
            var actual = sut.AddInts();
            Console.WriteLine("AddIntData value {0}", actual);
            Debug.WriteLine("AddIntData value  {0}", actual);
            //Assert
            try
            {
                Assert.That(actual, Is.EqualTo(expected));
            }
            catch(Exception ex)
            {
              
              //  Assert.Fail(ex.Message);
                Debug.WriteLine(ex.Message);
            }
           
           
           // Assert.Fail("Success");

        }

        [TestCaseSource(typeof(ExampleTestCaseSource))] // collect data from different class
        [Category("Collect Data")] // catagory example
        [MaxTime(30)] // test case failure if exist the test time.
        public void AddIntSourceClassData(int num1, int num2, int exp)
        {
            sut.StoreNum1 = num1;
            sut.StoreNum2 = num2;

            //Arrange
            var expected = exp;

            // Act
            var actual = sut.AddInts();
            Console.WriteLine("AddIntData value {0}", actual);
            Debug.WriteLine("AddIntData value  {0}", actual);
            //Assert
            try
            {
                Assert.That(actual, Is.EqualTo(expected));
            }
            catch (Exception ex)
            {

                //  Assert.Fail(ex.Message);
                Debug.WriteLine(ex.Message);
            }


            // Assert.Fail("Success");

        }
        [Test]
        [Ignore("Not now")]
        public void IgnorAttribute()
        {
            Debug.WriteLine("Ignor attribute ignore the test");
            Console.WriteLine("Ignor attribute ignore the test");
        }

        [TearDown]
        public void ExecuteAfterEachTest()
        {
            Debug.WriteLine("After execute each test");
        }

        [OneTimeTearDown]
        public void OneTimeTearExecute()
        {
            Debug.WriteLine("*** execute After test");
        }
    }

    public class ExampleTestCaseSource : IEnumerable
    {
        public IEnumerator GetEnumerator()
        {
            yield return new[] { 8, 4, 12 };
            yield return new[] { 5, 6, 11 };
            yield return new[] { 3, 9, 12 };
        }
    }
}
