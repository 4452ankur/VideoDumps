﻿using AllDataTypeUnitTesting.ClassLibrary;
using NUnit.Framework;
using System;
using System.Diagnostics;

namespace UnitTesting
{
    [TestFixture]
 public   class BeforeAfterTestCase
    {
        MemoryCalculater sut;

        [Test]
        public void ShouldAdd()
        {
            //Arrange
            var expected = 11;

            // Act
            var actual = sut.AddInts();
            Console.WriteLine("AddInts value {0}", actual);
            Debug.WriteLine("AddInts value {0}", actual);
            //Assert

            Assert.That(actual, Is.EqualTo(expected));
        }
        [Test]
        public void ShouldSubtract()
        {

            //Arrange
            var expected = -1;

            // Act
            var actual = sut.IntSubtra();
            Console.WriteLine("ShouldSubtract value {0}", actual);
            Debug.WriteLine("ShouldSubtract value {0}", actual);
            //Assert

            Assert.That(actual, Is.EqualTo(expected));
        }

        [SetUp] // execute before every test case
        public void BeforeEachTest()
        {
            Console.WriteLine("Before {0}", TestContext.CurrentContext.Test.Name);
            Debug.WriteLine("Before {0}", TestContext.CurrentContext.Test.Name);
            sut = new MemoryCalculater();
            sut.StoreNum1 = 6;
            sut.StoreNum2 = 5;
        }
        [TearDown] // execute after every test case

        public void AfterEachTest()
        {
            Console.WriteLine("After test {0}", TestContext.CurrentContext.Test.Name);
            Debug.WriteLine("After test {0}", TestContext.CurrentContext.Test.Name);
            sut = null;
           
        }
       [OneTimeSetUp]//starting  One time execute the code
       public static void BeforeExecuteAnyTest()
        {
            Console.WriteLine("Before execute test {0}");
            Debug.WriteLine("%%%%% Before execute test");
        }
        [OneTimeTearDown] // After end of One time execute code
        public static void AfterExecuteAllTest()
        {
            Console.WriteLine("After execute all test {0}");
            Debug.WriteLine("%%%%%After execute all test");
        }

        //[SetUp]
        //public void BeforeTest()
        //{ Console.WriteLine("BeforeTest"); }

        //[TearDown]
        //public void AfterTest()
        //{ Console.WriteLine("AfterTest"); }

        //[Test]
        //public void Test1()
        //{ Console.WriteLine("Test1"); }

        //[Test]
        //public void Test2()
        //{ Console.WriteLine("Test2"); }
    }
}
